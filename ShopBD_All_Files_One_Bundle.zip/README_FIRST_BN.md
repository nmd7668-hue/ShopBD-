# ShopBD — সব ফাইল একসঙ্গে

এই ZIP ফাইলের মধ্যে আগের ShopBD প্রজেক্টের বিভিন্ন সংস্করণ ও TNG manual payment কোড রাখা হয়েছে।

## কোন ফাইলটি ব্যবহার করবেন?
- `04_Firebase_Auth_Firestore_Starter.zip` — Firebase Authentication + Firestore starter; সর্বশেষ Firebase ভিত্তিক starter।
- `05_TNG_Manual_Payment_All_Code.zip` — TNG eWallet manual transfer details ও WhatsApp payment reference form-এর আলাদা demo।
- `03_Google_Login_Update.zip` — আগের Google login সংস্করণ।
- `02_COD_TouchNGo_Update.zip` — আগের COD/TNG checkout সংস্করণ।
- `01_Original_Full_Project.zip` — মূল ShopBD frontend starter।

## গুরুত্বপূর্ণ
এখানে একাধিক সংস্করণ রাখা হয়েছে যাতে আগের ফাইলগুলো হারিয়ে না যায়। এগুলো সব একটি master ZIP-এ রাখা হয়েছে, কিন্তু আলাদা ZIP-গুলোর কোড স্বয়ংক্রিয়ভাবে এক React অ্যাপে merge করা হয়নি—একই `src/main.jsx`/`package.json` একসঙ্গে বসালে পরস্পরকে overwrite করতে পারে।

TNG payment ZIP-টি manual payment UI; এটি আসল TNG/DuitNow API নয় এবং নিজে টাকা গ্রহণ/যাচাই করে না। আসল API-এর জন্য অনুমোদিত merchant access, credentials এবং secure backend/webhook প্রয়োজন।

Firebase config `.env` পূরণ ও Firebase Console-এর Authentication/Firestore সেটআপ করতে হবে। পুরোনো `google-services.json` ফাইলটি ShopBD project-এর config হিসেবে ব্যবহার করবেন না, যদি না project ID মিলে যাচাই করেন।
